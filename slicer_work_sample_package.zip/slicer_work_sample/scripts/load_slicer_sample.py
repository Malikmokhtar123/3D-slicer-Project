import os
import slicer

def load_sample():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    data_dir = os.path.join(base_dir, 'data')

    volume_path = os.path.join(data_dir, 'synthetic_abdominal_ct.nrrd')
    label_path = os.path.join(data_dir, 'synthetic_abdominal_labelmap.nrrd')
    color_path = os.path.join(data_dir, 'liver_lesion_colors.ctbl')
    markups_path = os.path.join(data_dir, 'lesion_center.mrk.json')

    loaded, color_node = slicer.util.loadColorTable(color_path, returnNode=True)
    if not loaded:
        raise RuntimeError('Failed to load color table')

    loaded, volume_node = slicer.util.loadVolume(volume_path, returnNode=True)
    if not loaded:
        raise RuntimeError('Failed to load CT volume')

    loaded, label_node = slicer.util.loadLabelVolume(
        label_path,
        {
            'colorNodeID': color_node.GetID()
        },
        returnNode=True
    )
    if not loaded:
        raise RuntimeError('Failed to load label map')

    segmentation_node = slicer.mrmlScene.AddNewNodeByClass('vtkMRMLSegmentationNode', 'SyntheticLiverSegmentation')
    segmentation_node.SetReferenceImageGeometryParameterFromVolumeNode(volume_node)
    slicer.modules.segmentations.logic().ImportLabelmapToSegmentationNode(label_node, segmentation_node)
    segmentation_node.CreateClosedSurfaceRepresentation()

    display_node = segmentation_node.GetDisplayNode()
    display_node.SetAllSegmentsVisibility(True)
    display_node.SetAllSegmentsVisibility3D(True)
    display_node.SetOpacity3D(0.55)
    display_node.SetOpacity2DFill(0.35)
    display_node.SetOpacity2DOutline(1.0)

    segmentation = segmentation_node.GetSegmentation()
    for i in range(segmentation.GetNumberOfSegments()):
        segment_id = segmentation.GetNthSegmentID(i)
        segment = segmentation.GetSegment(segment_id)
        if 'Liver' in segment.GetName():
            segment.SetColor(205/255.0, 144/255.0, 95/255.0)
        elif 'Lesion' in segment.GetName():
            segment.SetColor(220/255.0, 55/255.0, 55/255.0)

    slicer.util.loadMarkups(markups_path)
    slicer.util.setSliceViewerLayers(background=volume_node)
    slicer.app.applicationLogic().FitSliceToAll()

    # Optional volume rendering setup
    vr_logic = slicer.modules.volumerendering.logic()
    vr_display_node = vr_logic.CreateDefaultVolumeRenderingNodes(volume_node)
    vr_display_node.SetVisibility(True)
    preset = slicer.modules.volumerendering.logic().GetPresetByName('CT-AAA')
    if preset:
        vr_display_node.GetVolumePropertyNode().Copy(preset)
    vr_display_node.SetFollowVolumeDisplayNode(True)

    print('3D Slicer sample loaded successfully.')

load_sample()
