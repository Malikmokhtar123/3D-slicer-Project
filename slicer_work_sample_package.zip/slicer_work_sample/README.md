# 3D Slicer Work Sample - Synthetic Liver Lesion Segmentation

This package is a portfolio-ready 3D Slicer sample project built around a synthetic abdominal CT study. It includes a CT volume, a labelmap for liver and lesion segmentation, a fiducial placed at the lesion center, STL surface exports, measurement outputs, and a Python script that loads and styles the scene inside 3D Slicer.

## Files
- `data/synthetic_abdominal_ct.nrrd` - synthetic CT volume
- `data/synthetic_abdominal_labelmap.nrrd` - liver + lesion labelmap
- `data/liver_lesion_colors.ctbl` - label color table for Slicer
- `data/lesion_center.mrk.json` - fiducial markup at lesion center
- `data/liver_surface.stl` and `data/lesion_surface.stl` - surface mesh exports
- `outputs/slicer_preview_panel.png` - slice overlay preview
- `outputs/slicer_3d_view.png` - 3D surface preview
- `outputs/measurements.csv` - segment volumes and centroids
- `outputs/project_brief.pdf` - short portfolio brief
- `scripts/load_slicer_sample.py` - one-click scene loader for 3D Slicer

## What this demonstrates
- Medical image packaging in NRRD format
- Segmentation-ready labelmaps for 3D Slicer
- Fiducials and segment measurements
- Surface extraction to STL
- Basic automation with a Slicer Python script

## How to use in 3D Slicer
1. Open 3D Slicer.
2. Drag `scripts/load_slicer_sample.py` into the Slicer Python interactor, or open it from the Python console.
3. Run the script. It will:
   - load the CT volume
   - load the labelmap with a color table
   - convert the labelmap to a segmentation
   - create a 3D surface
   - load the lesion center fiducial
   - set up slice views and volume rendering

## Key measurements
- Liver volume: 33.488 mL
- Lesion volume: 1.734 mL
- Lesion center (LPS): (22.0, 0.0, 2.0)

## Notes
This is synthetic data created for portfolio and demonstration use. It is not clinical data and should not be used for diagnosis or research claims.
